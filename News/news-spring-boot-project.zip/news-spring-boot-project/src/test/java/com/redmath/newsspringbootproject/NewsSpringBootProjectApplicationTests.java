package com.redmath.newsspringbootproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
